def data_types():
    types = (1, '1', 1.1, False, [1, ], {'1': 1}, (1, ), {1, })
    print('[' + ", ".join([type(obj).__name__ for obj in types]) + ']')

if __name__ == '__main__':
    data_types()