import sys


def stock_price():
    COMPANIES = {
        'Apple': 'AAPL',
        'Microsoft': 'MSFT',
        'Netflix': 'NFLX',
        'Tesla': 'TSLA',
        'Nokia': 'NOK'
        }

    STOCKS = {
        'AAPL': 287.73,
        'MSFT': 173.79,
        'NFLX': 416.90,
        'TSLA': 724.88,
        'NOK': 3.37
    }

    if len(sys.argv) != 2:
        return

    company_abb = sys.argv[1].upper()
    invert = {}

    for key, value in COMPANIES.items():
        invert[value] = key
    
    name = invert.get(company_abb)
    price = STOCKS.get(company_abb)

    if name is None:
        print('Unknown ticker')
        return

    print(name, price)

if __name__ == "__main__":
    stock_price()