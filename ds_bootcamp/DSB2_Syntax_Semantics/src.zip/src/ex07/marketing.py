import sys


def marketing():
    if len(sys.argv) != 2:
        return

    task = sys.argv[1]

    clients = ['andrew@gmail.com', 'jessica@gmail.com', 'ted@mosby.com',
               'john@snow.is', 'bill_gates@live.com', 'mark@facebook.com',
               'elon@paypal.com', 'jessica@gmail.com']
    participants = ['walter@heisenberg.com', 'vasily@mail.ru',
                    'pinkman@yo.org', 'jessica@gmail.com', 'elon@paypal.com',
                    'pinkman@yo.org', 'mr@robot.gov', 'eleven@yahoo.com']
    recipients = ['andrew@gmail.com', 'jessica@gmail.com', 'john@snow.is']

    if task == 'call_center':
        print(call_center(clients, recipients))
    
    elif task == 'potential_clients':
        print(potential_clients(clients, participants))
    
    elif task == 'loyalty_program':
        print(loyalty_program(clients, participants))
    else:
        raise Exception('Unknown task') 
    
def call_center(clients: list, recipients: list) -> list:
    c = set(clients)
    r = set(recipients)
    return list(c - r)

def potential_clients(clients: list, participants: list) -> list:
    c = set(clients)
    p = set(participants)
    return list(p - c)

def loyalty_program(clients: list, participants: list) -> list:
    c = set(clients)
    p = set(participants)
    return list(c - p)

if __name__ == '__main__':
    marketing()