import sys


def main():
    if len(sys.argv) != 2 or not sys.argv[1].endswith('.txt'):
        return
    
    with open(sys.argv[1], 'r', encoding='utf-8') as fi:
        email_list = fi.read().split('\n')
    with open('employees.tsv', 'w', encoding='utf-8') as fo:
        chart = fo.write("Name\tSurname\tEmail\n")
        for email in email_list:
            email = email.strip()

            if not email:
                continue

            name, surname = email.split('.', 1)
            surname = surname.split('@')[0]
            chart = fo.write(f'{name.capitalize()}\t{surname.capitalize()}\t{email}\n')

if __name__ == '__main__':
    main()