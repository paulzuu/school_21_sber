import sys


def name_from_letter():
    if len(sys.argv) != 2:
        return
    
    email = sys.argv[1]

    with open('employees.tsv', 'r', encoding='utf-8') as fi:
        line = fi.read().strip().split('\n')

        for elem in line:
            elem = elem.split('\t')
            if email in elem[2]:
                print(f"Dear {elem[0]}, welcome to our team!\n"
                      f"We are sure that it will be a pleasure to work with you.\n"
                      f"That's a precondition for the professionals that our company hires.\n")

if __name__ == '__main__':
    name_from_letter()