import sys


def main():
    if len(sys.argv) != 4:
        raise Exception("Incorrect number of arguments. Usage: python caesar.py <encode|decode> '<text>' <shift>")
    
    operation = sys.argv[1].lower()
    text = sys.argv[2]
    
    try:
        shift_raw = int(sys.argv[3])
    except ValueError:
        raise Exception("Shift value must be an integer.")

    if operation not in ('encode', 'decode'):
        raise Exception(f"Invalid operation '{operation}'. Must be 'encode' or 'decode'.")

    check_for_unsupported_chars(text)

    effective_shift = shift_raw if operation == 'encode' else -shift_raw

    result = caesar_cipher(text, effective_shift)
    print(result)

def caesar_cipher(text, shift):
    result = ""
    
    for char in text:
        if 'A' <= char <= 'Z':
            new_char_code = ((ord(char) - ord('A') + shift) % 26) + ord('A')
            result += chr(new_char_code)
        elif 'a' <= char <= 'z':
            new_char_code = ((ord(char) - ord('a') + shift) % 26) + ord('a')
            result += chr(new_char_code)
        else:
            result += char
    return result

def check_for_unsupported_chars(text):
    for char in text:
        if char.isalpha() and not ('A' <= char.upper() <= 'Z'):
             raise Exception("The script does not support your language yet.")

if __name__ == '__main__':
    main()