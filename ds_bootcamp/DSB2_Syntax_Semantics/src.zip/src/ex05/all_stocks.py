import sys


def main():
    
    if len(sys.argv) != 2:
        return
    
    line = sys.argv[1]

    if ",," in line.replace(' ', ''):
        return
    
    all_list = line.split(',')
    
    for elem in all_list:
        item = elem.strip()
        res = process(item)
        if res is not None:
            print(res)

def process(item: str) -> str | None:

    COMPANIES = {
        'Apple': 'AAPL',
        'Microsoft': 'MSFT',
        'Netflix': 'NFLX',
        'Tesla': 'TSLA',
        'Nokia': 'NOK'
        }

    STOCKS = {
        'AAPL': 287.73,
        'MSFT': 173.79,
        'NFLX': 416.90,
        'TSLA': 724.88,
        'NOK': 3.37
        }
    
    if not item:
        return None

    ticker = item.upper()
    comp = item.title()

    for name, tick in COMPANIES.items():
        if tick == ticker:
            return (f'{ticker} is a ticker symbol for {name}')
    
    for name in COMPANIES:
        if name == comp:
            return (f'{comp} stock price is {STOCKS[COMPANIES[comp]]}')

    return (f'{item} is an unknown company or an unknown ticker symbol')
        
if __name__ == '__main__':
    main()