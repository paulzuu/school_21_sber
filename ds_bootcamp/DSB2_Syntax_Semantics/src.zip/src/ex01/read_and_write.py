def read_write():
    with open("../../datasets/ds.csv", encoding='utf-8') as fin:
        with open("ds.tsv", 'w', encoding='utf-8') as fout:

            data = [line.strip('\n') for line in fin.readlines()]
            
            for line in data:
                fout.write(csv_to_tsv(line) + '\n')


def csv_to_tsv(line: str) -> str:

    tokens = ''
    count = 0

    for symb in line:
        if symb == '"':
            count += 1
        if count % 2 == 0 and symb == ',':
            tokens += '\t'
        else:
            tokens += symb

    return tokens


if __name__ == "__main__":
    read_write()