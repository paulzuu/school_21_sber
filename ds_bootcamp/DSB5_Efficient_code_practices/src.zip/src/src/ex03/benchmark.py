#!/usr/bin/env python

import sys
import timeit
from functools import reduce


def loop(deg):
    summ = 0

    for num in range(1, deg + 1):
        summ += num * num

    return summ

def reduce_func(deg):
    return reduce(lambda summ, num: summ + num * num, range(1, deg + 1), 0)

def benchmark():
    available_funcs = {
        'loop': loop,
        'reduce_func': reduce_func
    }
    
    if len(sys.argv) != 4:
        print("Error: wrong num of arguments.\nUsage: ./benchmark.py <func> runs_num degree", file=sys.stderr)
        sys.exit(1)

    func_name = sys.argv[1].lower()
    
    if func_name not in available_funcs:
        print(f"Error: wrong func_name '{func_name}'. Available: loop, reduce", file=sys.stderr)
        sys.exit(1)

    try:
        num_runs = int(sys.argv[2])
        if num_runs <= 0:
             raise ValueError
    except ValueError:
        print(f"Error: runs_num '{sys.argv[2]}' must be a positive integer.", file=sys.stderr)
        sys.exit(1)

    try:
        degree = int(sys.argv[3])
        if degree < 0:
             raise ValueError
    except ValueError:
        print(f"Error: degree '{sys.argv[3]}' must be a possitive integer.", file=sys.stderr)
        sys.exit(1)
        
    
    target_func = available_funcs[func_name]
    
    timing = timeit.timeit(
        lambda: target_func(degree),
        number=num_runs
    )
    
    print(f"{timing:.11f}")

if __name__ == '__main__':
    benchmark()