#!/usr/bin/env python

import sys
import timeit

def loop(emails):
    res = []

    for e in emails:
        if e.endswith('@gmail.com'):
            res.append(e)
    return res


def list_comprehension(emails):
    return [e for e in emails if e.endswith('@gmail.com')]

def map_emails(emails):
    mapped = list(map(lambda e: e if e.endswith('@gmail.com') else None, emails ))

    return [e for e in mapped if e is not None]

def filtering(emails):
    return list(filter(lambda e: e.endswith('@gmail.com'), emails))

def run_benchmarks():
    raw_emails = ['john@gmail.com', 'james@gmail.com', 'alice@yahoo.com',
                  'anna@live.com', 'philipp@gmail.com'
                  ]
    all_funcs = {'loop': loop, 'list_comprehension': list_comprehension,
                 'map_emails': map_emails, 'filtering': filtering
                 }

    rep_emails = []
    for _ in range(5):
        rep_emails.extend(raw_emails)

    if len(sys.argv) != 3:
        print('Error: wrong nums of arguments. Usage: ./benchmark.py <func> run_num', file=sys.stderr)
        print(f'Available functions: {", ".join([f for f in all_funcs.keys()])}', file=sys.stderr)
        sys.exit(1)

    func_name = sys.argv[1].lower()

    if func_name not in all_funcs:
        print(f'Error: function {func_name} is not recongnized', file=sys.stderr)
        print(f'Available functions: {", ".join([f for f in all_funcs.keys()])}', file=sys.stderr)
        sys.exit(1)

    try:
        num_calls = int(sys.argv[2])
        
        if num_calls <= 0:
            raise ValueError
    except ValueError:
        print(f'Error: {sys.argv[2]} must positive intgers of function calls', file=sys.stderr)
        sys.exit(1)

    target_func = all_funcs[func_name]

    timing = timeit.timeit(
        lambda: target_func(rep_emails),
        number=num_calls
    )

    print(f'{timing:.11f}')

if __name__ == '__main__':
    run_benchmarks()