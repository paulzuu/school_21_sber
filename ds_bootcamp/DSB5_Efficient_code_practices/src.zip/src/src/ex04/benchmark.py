#!/usr/bin/env python

import timeit
import random
from collections import Counter
import sys


def count_manually(data_list):
    counts = {}

    for num in data_list:
        counts[num] = counts.get(num, 0) + 1

    return counts

def count_Counter(data_list):

    return Counter(data_list)

def top10_manually(data_list):

    counts = count_manually(data_list)
    sorted_items = sorted(counts.items(), key=lambda item: item[1], reverse=True)

    return sorted_items[:10]

def top10_Counter(data_list):

    counter = Counter(data_list)

    return counter.most_common(10)

def run_benchmark():

    list_size = 1_000_000
    max_value = 100
    runs_num = 10

    random_data = [random.randint(0, max_value) for _ in range(list_size)]

    results = {}

    results['my_func'] = timeit.timeit(
        lambda: count_manually(random_data),
        number=runs_num
    )

    results['Counter'] = timeit.timeit(
        lambda: count_Counter(random_data),
        number=runs_num
    )

    results['my_top10'] = timeit.timeit(
        lambda: top10_manually(random_data),
        number=runs_num
    )

    results['Counter_top10'] = timeit.timeit(
        lambda: top10_Counter(random_data),
        number=runs_num
    )

    print(f'My function: {results['my_func']:.7f}')
    print(f'Counter: {results['Counter']:.7f}')

    print(f'My top 10: {results['my_top10']:.7f}')
    print(f'Counter top 10: {results['Counter_top10']:.7f}')


if __name__ == '__main__':
    run_benchmark()