#!/usr/bin/env python

import sys
import os
import psutil
import time


def read_file_to_list(filepath):
 
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = f.readlines()
            return data
    except FileNotFoundError:
        print(f"Error: File not found at {filepath}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error occurred during file reading: {e}", file=sys.stderr)
        sys.exit(1)

def format_usage_windows(start_cpu_time, end_cpu_time):
   
    proc = psutil.Process(os.getpid())
    cpu_time = end_cpu_time - start_cpu_time
    current_memory_bytes = proc.memory_info().rss 
    peak_memory_gb = current_memory_bytes / (1024 ** 3) 
    
    print(f"Peak Memory Usage = {peak_memory_gb:.3f} GB")
    print(f"User Mode Time + System Mode Time = {cpu_time:.2f}s")

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Usage: ./ordinary.py <path_to_ratings.csv>", file=sys.stderr)
        sys.exit(1)
        
    filepath = sys.argv[1]
    start_cpu_time = time.process_time()
    data_list = read_file_to_list(filepath)

    for line in data_list:
        pass

    end_cpu_time = time.process_time()
    
    format_usage_windows(start_cpu_time, end_cpu_time)