import timeit

def loop():
    emails = ['john@gmail.com', 'james@gmail.com', 'alice@yahoo.com',
              'anna@live.com', 'philipp@gmail.com'
              ]
    res = []

    for e in emails:
        for _ in range(5):
            if e.endswith('@gmail.com'):
                res.append(e)
    return res


def list_comprehension():
    emails = ['john@gmail.com', 'james@gmail.com', 'alice@yahoo.com',
              'anna@live.com', 'philipp@gmail.com'
              ]
    return [e for e in emails for _ in range(5) if e.endswith('@gmail.com')]

def run_benchmarks():
    run_nums = 90_000_000

    loop_time = timeit.timeit(
        'loop()',
        setup='from __main__ import loop',
        number=run_nums
    )

    comprehension_time = timeit.timeit(
        'list_comprehension()',
        setup='from __main__ import list_comprehension',
        number=run_nums
    )

    times = [loop_time, comprehension_time]

    if comprehension_time <= loop_time:
        print(f'It is better to use a list comprehension')
    else:
        print(f'It is better to use a loop')

    sorted_times = sorted(times)
    print(f'{sorted_times[0]:.11f} vs {sorted_times[1]:.11f}')

if __name__ == '__main__':
    run_benchmarks()