import timeit

def loop():
    emails = ['john@gmail.com', 'james@gmail.com', 'alice@yahoo.com',
              'anna@live.com', 'philipp@gmail.com'
              ]
    res = []

    for e in emails:
        for _ in range(5):
            if e.endswith('@gmail.com'):
                res.append(e)
    return res


def list_comprehension():
    emails = ['john@gmail.com', 'james@gmail.com', 'alice@yahoo.com',
              'anna@live.com', 'philipp@gmail.com'
              ]
    return [e for e in emails for _ in range(5) if e.endswith('@gmail.com')]

def map_emails():
    emails = ['john@gmail.com', 'james@gmail.com', 'alice@yahoo.com',
              'anna@live.com', 'philipp@gmail.com'
              ]
    email_5 = [e for e in emails for _ in range(5)]
    mapped = list(map(lambda e: e if e.endswith('@gmail.com') else None, email_5))

    return [e for e in mapped if e is not None]

def run_benchmarks():
    run_nums = 90_000_000

    loop_time = timeit.timeit(
        'loop()',
        setup='from __main__ import loop',
        number=run_nums
    )

    comprehension_time = timeit.timeit(
        'list_comprehension()',
        setup='from __main__ import list_comprehension',
        number=run_nums
    )

    map_time = timeit.timeit(
        'map_emails()',
        setup='from __main__ import map_emails',
        number=run_nums
    )

    results = [{'time': loop_time, 'method': 'loop'},
               {'time': comprehension_time, 'method': 'comprehension'},
               {'time': map_time, 'method': 'map'}
               ]
    
    sorted_results = sorted(results, key=lambda x: x['time'])
    winner = sorted_results[0]

    if winner['method'] == 'map':
        print(f'It is better to use a list map')
    elif winner['method'] == 'comprehension':
        print(f'It is better to use a list comprehension')
    else:
        print(f'It is better to use a loop')

    print(" vs ".join([f"{r['time']:.11f}" for r in sorted_results]))

if __name__ == '__main__':
    run_benchmarks()