#!/bin/sh
if [ $# -eq 0 ]; then
	vac="data scientist"
else
	vac=$1
fi

curl -G "https://api.hh.ru/vacancies" --data-urlencode "text=$vac" -d "per_page=20" | jq > hh.json
