#!/bin/sh
{ 
    head -n 1 ../ex02/hh_sorted.csv; 
    tail -n 20 ../ex02/hh_sorted.csv | awk -F ',' '
BEGIN{FS=OFS=","}
{
    w = ""
    line = $3
    while (match(line, /([Jj]unior|[Mm]iddle|[Ss]enior)/)) {
        found = substr(line, RSTART, RLENGTH)
        found = toupper(substr(found,1,1)) tolower(substr(found,2))
        w = w ? w"/"found : found
        line = substr(line, RSTART + RLENGTH)
    }
    buff = w ? w : "-"
    buff = "\"" buff
    $3 = buff "\"" 
    print 
}
'; } | cat > hh_positions.csv