#!/bin/sh
{
    echo '"name","count"'
    awk -F, '
    NR>1 {
        gsub(/"/, "", $3)
        count[$3]++
    } 
    END {
        for (name in count) 
            print "\"" name "\"," count[name]
    }' ../ex03/hh_positions.csv | sort -t, -k2,2nr
} > hh_uniq_positions.csv