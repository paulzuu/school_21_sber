import sys
import os


class Research:

    class Calculations:

        def counts(self, data):
            heads = sum(row[0] for row in data)
            tails = sum(row[1] for row in data)
            
            return heads, tails

        def fractions(self, heads, tails):
            total = heads + tails
            
            if total == 0:
                return 0, 0
            
            h_frac = heads / total
            t_frac = tails / total
            
            return h_frac, t_frac
            
    def __init__(self, path):
        self.path = path
    
    def file_reader(self, has_header=True):
        if not os.path.exists(self.path):
            raise FileNotFoundError(f"File {self.path} not found")
        
        with open(self.path, 'r', encoding='utf-8') as fi:
            data = fi.read()
        
        if not self.check_structure(data, has_header):
            raise ValueError(f"File {self.path} has wrong structure")
        
        data_list = [line.strip() for line in data.split('\n') if line.strip()]
        start_idx = 1 if has_header and len(data_list) > 1 else 0
        new_list = []

        for elem in data_list[start_idx:]:
            new_list.append([int(num) for num in elem.split(',')])

        return new_list

    def check_structure(self, data, has_header):
        lines = [line.strip() for line in data.split('\n') if line.strip()]
        
        if len(lines) < 1:
            return False
        
        start_check = 0

        if has_header:
            if len(lines) < 2:
                return False
            
            header = [h.strip() for h in lines[0].split(',')]
            
            if header[0] in ['0', '1'] or header[1] in ['0', '1']:
                return False

            if len(header) != 2 or not header[0] or not header[1]:
                return False
            
            start_check = 1

        for line in lines[start_check:]:
            values = [v.strip() for v in line.split(',')]
            
            if len(values) != 2:
                return False
            
            if not (values[0] in ['0', '1'] and values[1] in ['0', '1']):
                return False
            
            if values[0] == values[1]:
                return False
        
        return True

def main():
    if len(sys.argv) != 2:
        raise Exception("Wrong number of arguments. Usage: python first_nest.py <file_path>")

    research = Research(sys.argv[1])
    data = research.file_reader(has_header=True)
    print(data)

    calculation = research.Calculations()

    heads, tails = calculation.counts(data)
    print(f'{heads} {tails}')

    h_frac, t_frac = calculation.fractions(heads, tails)
    print(f'{h_frac:.4f} {t_frac:.4f}')

if __name__ == '__main__':
   try:
       main()
   except Exception as e:
       print(f"Error: {e}")
       sys.exit(1)