class Must_Read:

    try:
        with open('../../datasets/data.csv', 'r', encoding='utf-8') as fi:
            data = fi.read()
            print(data)
    except FileNotFoundError:
        print("Error: datasets/data.csv file not found")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == '__main__':
    Must_Read()
