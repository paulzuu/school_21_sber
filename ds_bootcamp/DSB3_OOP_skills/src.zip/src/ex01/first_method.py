class Research:

    def file_reader(self):
        with open('../../datasets/data.csv', 'r', encoding='utf-8') as fi:
            return fi.read()

def main():
    try:
        research = Research()
        result = research.file_reader()
        print(result)
    except FileNotFoundError:
        print("Error: datasets/data.csv file not found")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == '__main__':
    main()
