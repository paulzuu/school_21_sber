import config
from analytics import Research, Analytics


def main():
    research = Research(config.data_file_path)
    try:
        data = research.file_reader(has_header=config.has_header)
    except (FileNotFoundError, ValueError) as e:
        print(f"Error reading or validating file: {e}")
        return

    analytics = Analytics(data)
    heads, tails = analytics.counts()
    total = heads + tails
    h_frac, t_frac = analytics.fractions(heads, tails)

    random_pred = analytics.predict_random(config.num_of_steps)

    heads_pred, tails_pred = analytics.count_predictions(random_pred)

    report = config.report_template.format(
        total_observ=total,
        tails=tails,
        heads=heads,
        tails_frac=t_frac * 100,
        heads_frac=h_frac * 100,
        num_of_steps=config.num_of_steps,
        tails_pred=tails_pred,
        heads_pred=heads_pred
    )

    print(report)
    
    if analytics.save_file(report, 'report', config.report_extension):
        print(f"Report is successfully saved as report.{config.report_extension}")
    else:
        print("Error saving report.")

if __name__ == '__main__':
    main()