import config
from analytics import Research, Analytics
import logging
from logging.handlers import RotatingFileHandler

formatter = logging.Formatter(config.log_format, datefmt="%Y-%m-%d %H:%M:%S")
file_handler = logging.FileHandler(config.log_file)
file_handler.setFormatter(formatter)
file_handler.setLevel(logging.DEBUG)

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
logger.addHandler(file_handler)

def main():
    report_created = False
    notification_message = "Report is not created because of error."

    research = Research(config.data_file_path)

    try:
        data = research.file_reader(has_header=config.has_header)
    except (FileNotFoundError, ValueError) as e:
        print(f"Error reading or validating file: {e}")
        logging.critical(f"FATAL ERROR: Report generation failed at file reading/validation: {e}")
        research.send_tg_notific(config.tg_token, config.chat_id, notification_message)
        return

    analytics = Analytics(data)
    heads, tails = analytics.counts()
    total = heads + tails
    h_frac, t_frac = analytics.fractions(heads, tails)

    random_pred = analytics.predict_random(config.num_of_steps)

    heads_pred, tails_pred = analytics.count_predictions(random_pred)

    report = config.report_template.format(
        total_observ=total,
        tails=tails,
        heads=heads,
        tails_frac=t_frac * 100,
        heads_frac=h_frac * 100,
        num_of_steps=config.num_of_steps,
        tails_pred=tails_pred,
        heads_pred=heads_pred
    )

    print(report)
    
    if analytics.save_file(report, 'report', config.report_extension):
        print(f"Report is successfully saved as report.{config.report_extension}")
        report_created = True
        notification_message = "Report is successfully created."
    else:
        print("Error saving report.")

    research.send_tg_notific(config.tg_token, config.chat_id, notification_message)

if __name__ == '__main__':
    main()