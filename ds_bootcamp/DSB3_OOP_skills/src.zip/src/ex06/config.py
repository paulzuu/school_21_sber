num_of_steps = 3
data_file_path = '../../datasets/data.csv'
report_extension = 'txt'
has_header = True

tg_token = '8394502604:AAEXHaPwh36zgxQFs0q6aIwrCTHyHcrfIJI'
chat_id = -1003483384553

log_file = 'analytics.log'
log_format = '%(asctime)s %(levelname)s %(message)s'

report_template = (
    "We made {total_observ} observations by tossing a coin: {tails} were tails and {heads} were heads.\n"
    "The probabilities are {tails_frac:.2f}% and {heads_frac:.2f}%, respectively.\n"
    "Our forecast is that the next {num_of_steps} observations will be: {heads_pred} heads and {tails_pred} tails.\n"
)