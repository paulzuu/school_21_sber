import os
from random import randint
import logging, requests

class Research:

    def __init__(self, path):
        self.path = path
        logging.info(f"Research object initialized with path: {path}")

    def file_reader(self, has_header):
        logging.info("Starting file_reader method.")
        if not os.path.exists(self.path):
            logging.error(f"File not found at path: {self.path}")
            raise FileNotFoundError(f"File {self.path} not found")
        
        with open(self.path, 'r', encoding='utf-8') as fi:
            data = fi.read()
            logging.debug("Data successfully read from file.")
        
        if not self.check_structure(data, has_header):
            logging.error(f"File {self.path} has wrong structure.")
            raise ValueError(f"File {self.path} has wrong structure")
        
        data_list = [line.strip() for line in data.split('\n') if line.strip()]
        start_idx = 1 if has_header and len(data_list) > 1 else 0
        new_list = []

        for elem in data_list[start_idx:]:
            new_list.append([int(num) for num in elem.split(',')])

        logging.info(f"File successfully parsed. {len(new_list)} data rows found.")
        return new_list

    def check_structure(self, data, has_header):
        logging.info("Starting check_structure method.")
        lines = [line.strip() for line in data.split('\n') if line.strip()]
        
        if len(lines) < 1:
            logging.warning("File is empty.")
            return False
        
        start_check = 0

        if has_header:
            if len(lines) < 2:
                logging.warning("File has header but no data.")
                return False
            
            header = [h.strip() for h in lines[0].split(',')]
            
            if header[0] in ['0', '1'] and header[1] in ['0', '1']:
                 return False

            if len(header) != 2 or not header[0] or not header[1]:
                return False
            
            start_check = 1

        for line in lines[start_check:]:
            values = [v.strip() for v in line.split(',')]
            
            if len(values) != 2:
                logging.warning(f"Row {line} has incorrect column count.")
                return False
            
            if not (values[0] in ['0', '1'] and values[1] in ['0', '1']):
                logging.warning(f"Row {line} has invalid data values.")
                return False
            
            if values[0] == values[1]:
                logging.warning(f"Row {line} has impossible combination (1,1 or 0,0).")
                return False
        
        logging.info("Structure check passed successfully.")
        return True
    
    def send_tg_notific(self, tg_token, chat_id, message):
        logging.info(f"Attempting to send Telegram notification: '{message}'")
        url = f"https://api.telegram.org/bot{tg_token}/sendMessage"

        payload = {
            'chat_id': chat_id,
            'text': message
        }
        
        try:
            response = requests.post(url, data=payload)
            response.raise_for_status()
            logging.info("Telegram notification sent successfully.")
            return True
        except requests.exceptions.RequestException as e:
            logging.error(f"Failed to send Telegram notification: {e}")
            return False
    
class Calculations:
    def __init__(self, data):
        self.data = data
        logging.info("Calculations object initialized.")
    
    def counts(self):
        logging.info("Calculating the counts of heads and tails.")
        heads = sum(row[0] for row in self.data)
        tails = sum(row[1] for row in self.data)
        
        logging.debug(f"Heads: {heads}, Tails: {tails}")
        return heads, tails

    def fractions(self, heads, tails):
        logging.info("Calculating fractions (probabilities).")
        
        total = heads + tails
        
        if total == 0:
            logging.warning("Total observations is zero, fractions returned as 0.")
            return 0, 0
        
        h_frac = heads / total
        t_frac = tails / total
        
        logging.debug(f"Heads frac: {h_frac:.2f}, Tails frac: {t_frac:.2f}")
        return h_frac, t_frac

    
class Analytics(Calculations):
    
    def predict_random(self, num_predictions):
        logging.info(f"Generating {num_predictions} random predictions.")
        
        predictions = []
        for _ in range(num_predictions):
            head_or_tail = randint(0, 1)
            
            if head_or_tail == 1:
                predictions.append([1, 0])
            else:
                predictions.append([0, 1])

        logging.debug(f"Generated predictions: {predictions}")      
        return predictions

    def predict_last(self):
        logging.info("Returning last observation.")
        
        if self.data:
            return self.data[-1] 
        
        logging.warning("Data is empty, predict_last returning empty list.")
        return []

    def save_file(self, data, filename, extension):
        logging.info(f"Attempting to save report to {filename}.{extension}")
        
        full_path = f"{filename}.{extension}"
        
        try:
            with open(full_path, 'w', encoding='utf-8') as f:
                f.write(data) 
            logging.info(f"Report successfully saved to {full_path}.")
            return True
        except Exception as e:
            logging.error(f"Error saving report: {e}")
            return False
        
    def count_predictions(self, predictions):
        logging.info("Counting heads and tails in predictions.")
        
        heads = sum(row[0] for row in predictions)
        tails = sum(row[1] for row in predictions)
        
        logging.debug(f"Prediction result: Heads={heads}, Tails={tails}")
        return heads, tails