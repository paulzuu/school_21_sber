import sys
import os

class Research:

    def __init__(self, path):
        self.path = path
    
    def file_reader(self):
        if not os.path.exists(self.path):
            raise FileNotFoundError(f"File {self.path} not found")
        
        with open(self.path, 'r', encoding='utf-8') as fi:
            data = fi.read()
        
        if not self.check_structure(data):
            raise ValueError(f"File {self.path} has wrong structure")
        
        return data

    def check_structure(self, data):
        lines = [line.strip() for line in data.split('\n') if line.strip()]
        
        if len(lines) < 2:
            return False
        
        header = [h.strip() for h in lines[0].split(',')]
        if len(header) != 2:
            return False
        
        if not header[0] or not header[1]:
            return False
        
        for line in lines[1:]:
            values = [v.strip() for v in line.split(',')]
            if len(values) != 2:
                return False
            if not (values[0] in ['0', '1'] and values[1] in ['0', '1']):
                return False
            if values[0] == values[1]:
                return False
        
        return True

def main():
    if len(sys.argv) != 2:
        raise Exception("Wrong number of arguments. Usage: python first_constructor.py <file_path>")

    research = Research(sys.argv[1])
    print(research.file_reader())

if __name__ == '__main__':
   try:
       main()
   except Exception as e:
       print(f"Error: {e}")
       sys.exit(1)